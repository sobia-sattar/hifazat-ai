import { Navigate, Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import AnalyticsPage from "./pages/Analytics";
import DashboardPage from "./pages/Dashboard";
import ExplainabilityPage from "./pages/Explainability";
import LivePage from "./pages/Live";
import ResearchPage from "./pages/Research";
import SettingsPage from "./pages/Settings";
import TextAnalyzerPage from "./pages/TextAnalyzer";
import YoutubePage from "./pages/Youtube";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/analyzer" element={<TextAnalyzerPage />} />
        <Route path="/youtube" element={<YoutubePage />} />
        <Route path="/live" element={<LivePage />} />
        <Route path="/analytics" element={<AnalyticsPage />} />
        <Route path="/explainability" element={<ExplainabilityPage />} />
        <Route path="/research" element={<ResearchPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
