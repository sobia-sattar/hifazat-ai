import { NavLink, Outlet } from "react-router-dom";

const links = [
  ["/", "Dashboard"],
  ["/analyzer", "Text Analyzer"],
  ["/youtube", "YouTube Analyzer"],
  ["/live", "Live Sentinel"],
  ["/analytics", "Analytics"],
  ["/explainability", "Explainability"],
  ["/research", "Research Lab"],
  ["/settings", "Settings"],
];

export default function Layout() {
  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-line bg-panel/80 p-5 lg:block">
        <div className="mb-8">
          <p className="text-xs uppercase tracking-[0.2em] text-sky-400">BullyLens-X</p>
          <h1 className="mt-1 text-xl font-semibold">Detect. Explain. Understand.</h1>
        </div>
        <nav className="space-y-1">
          {links.map(([to, label]) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              className={({ isActive }) =>
                `block rounded-xl px-3 py-2 text-sm ${isActive ? "bg-sky-500/15 text-sky-300" : "text-slate-300 hover:bg-white/5"}`
              }
            >
              {label}
            </NavLink>
          ))}
        </nav>
        <p className="mt-10 text-xs leading-5 text-slate-500">
          AI predictions may contain errors. High-risk content should be reviewed by a human moderator.
        </p>
      </aside>
      <div className="lg:pl-64">
        <header className="sticky top-0 z-10 border-b border-line bg-ink/80 px-4 py-3 backdrop-blur lg:hidden">
          <p className="text-sm font-semibold">BullyLens-X</p>
          <div className="mt-2 flex gap-2 overflow-x-auto text-xs">
            {links.map(([to, label]) => (
              <NavLink key={to} to={to} className="whitespace-nowrap rounded-full border border-line px-3 py-1">
                {label}
              </NavLink>
            ))}
          </div>
        </header>
        <main className="mx-auto max-w-7xl px-4 py-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
