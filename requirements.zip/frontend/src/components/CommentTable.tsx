import { useMemo, useState } from "react";
import type { CommentRow } from "../types";

export default function CommentTable({
  rows,
  onOpen,
}: {
  rows: CommentRow[];
  onOpen: (row: CommentRow) => void;
}) {
  const [q, setQ] = useState("");
  const [lang, setLang] = useState("all");
  const [cls, setCls] = useState("all");
  const [risk, setRisk] = useState("all");
  const [cat, setCat] = useState("all");
  const [minConf, setMinConf] = useState(0);
  const [sort, setSort] = useState<"confidence" | "language" | "classification">("confidence");
  const [page, setPage] = useState(0);
  const pageSize = 10;

  const filtered = useMemo(() => {
    return rows
      .filter((r) => r.original_text.toLowerCase().includes(q.toLowerCase()))
      .filter((r) => lang === "all" || r.language === lang)
      .filter((r) => cls === "all" || r.classification === cls)
      .filter((r) => risk === "all" || r.risk === risk)
      .filter((r) => cat === "all" || r.category === cat || (r.categories?.[cat] || 0) >= 0.5)
      .filter((r) => r.confidence >= minConf)
      .sort((a, b) => {
        if (sort === "confidence") return b.confidence - a.confidence;
        return String(a[sort]).localeCompare(String(b[sort]));
      });
  }, [rows, q, lang, cls, risk, cat, minConf, sort]);

  const pageRows = filtered.slice(page * pageSize, page * pageSize + pageSize);
  const langs = Array.from(new Set(rows.map((r) => r.language)));

  return (
    <div className="card overflow-hidden">
      <div className="grid gap-2 border-b border-line p-4 md:grid-cols-6">
        <input className="input md:col-span-2" placeholder="Search comments" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} />
        <select className="input" value={lang} onChange={(e) => setLang(e.target.value)}>
          <option value="all">Language</option>
          {langs.map((l) => (
            <option key={l}>{l}</option>
          ))}
        </select>
        <select className="input" value={cls} onChange={(e) => setCls(e.target.value)}>
          <option value="all">Classification</option>
          <option>SAFE</option>
          <option>BULLYING</option>
          <option>UNCERTAIN</option>
        </select>
        <select className="input" value={risk} onChange={(e) => setRisk(e.target.value)}>
          <option value="all">Risk</option>
          <option>LOW</option>
          <option>MEDIUM</option>
          <option>HIGH</option>
          <option>CRITICAL</option>
          <option>REVIEW</option>
        </select>
        <select className="input" value={cat} onChange={(e) => setCat(e.target.value)}>
          <option value="all">Category</option>
          <option>INSULT</option>
          <option>HARASSMENT</option>
          <option>THREAT</option>
          <option>HATE_SPEECH</option>
          <option>CYBERBULLYING</option>
          <option>TOXIC</option>
        </select>
        <label className="text-xs text-slate-400">
          Min confidence {minConf.toFixed(2)}
          <input type="range" min={0} max={1} step={0.05} value={minConf} onChange={(e) => setMinConf(Number(e.target.value))} className="w-full" />
        </label>
        <select className="input" value={sort} onChange={(e) => setSort(e.target.value as any)}>
          <option value="confidence">Sort: confidence</option>
          <option value="language">Sort: language</option>
          <option value="classification">Sort: classification</option>
        </select>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 text-slate-400">
            <tr>
              <th className="px-4 py-3">Comment</th>
              <th className="px-4 py-3">Language</th>
              <th className="px-4 py-3">Classification</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Confidence</th>
              <th className="px-4 py-3">Risk</th>
              <th className="px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {pageRows.map((r) => (
              <tr key={r.id} className="border-t border-line/80 hover:bg-white/5">
                <td className="max-w-sm truncate px-4 py-3" title={r.original_text}>{r.original_text}</td>
                <td className="px-4 py-3">{r.language}</td>
                <td className="px-4 py-3">{badge(r.classification)}</td>
                <td className="px-4 py-3">{r.category}</td>
                <td className="px-4 py-3">{(r.confidence * 100).toFixed(1)}%</td>
                <td className="px-4 py-3">{r.risk}</td>
                <td className="px-4 py-3">
                  <button className="btn-ghost !px-3 !py-1" onClick={() => onOpen(r)}>
                    Review
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between p-4 text-sm text-slate-400">
        <span>{filtered.length} comments</span>
        <div className="flex gap-2">
          <button className="btn-ghost" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Prev</button>
          <button className="btn-ghost" disabled={(page + 1) * pageSize >= filtered.length} onClick={() => setPage((p) => p + 1)}>Next</button>
        </div>
      </div>
    </div>
  );
}

function badge(c: string) {
  const color = c === "SAFE" ? "text-emerald-300" : c === "UNCERTAIN" ? "text-amber-300" : "text-rose-300";
  return <span className={`font-semibold ${color}`}>{c === "BULLYING" ? "🔴 BULLYING" : c === "SAFE" ? "SAFE" : "UNCERTAIN"}</span>;
}
