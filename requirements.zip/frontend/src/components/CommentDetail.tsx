import { api } from "../services/api";
import type { CommentRow } from "../types";

export default function CommentDetail({ row, onClose }: { row: CommentRow; onClose: () => void }) {
  const highlights = row.xai?.highlights || [];
  return (
    <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/60 p-4">
      <div className="card max-h-[90vh] w-full max-w-3xl overflow-y-auto p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-wide text-sky-400">Comment detail</p>
            <h2 className="mt-1 text-xl font-semibold">{row.classification} · {(row.confidence * 100).toFixed(1)}%</h2>
          </div>
          <button className="btn-ghost" onClick={onClose}>Close</button>
        </div>
        <section className="mt-4 space-y-3 text-sm">
          <p><span className="text-slate-400">Original:</span> {row.original_text}</p>
          <p><span className="text-slate-400">Normalized:</span> {row.normalized_text}</p>
          <p>Language {row.language} ({(row.language_confidence * 100).toFixed(1)}%) · Script {row.script} · Code-mixed {String(row.is_code_mixed)}</p>
          <p>Risk {row.risk} · Primary {row.primary_category || row.category}</p>
          <div className="flex flex-wrap gap-2">
            {Object.entries(row.categories || {}).filter(([, v]) => v >= 0.5).map(([k, v]) => (
              <span key={k} className="rounded-full border border-line px-2 py-1 text-xs">{k} {(v * 100).toFixed(0)}%</span>
            ))}
          </div>
          {row.is_code_mixed && (
            <div>
              <p className="text-slate-400">Word-level code-mixing</p>
              <div className="mt-1 flex flex-wrap gap-1">
                {(row.code_mix_tokens || []).map((t, i) => (
                  <span key={i} className="rounded bg-white/5 px-2 py-1 text-xs">{t.token} → {t.language}</span>
                ))}
              </div>
            </div>
          )}
          <div>
            <p className="font-medium text-sky-300">Why?</p>
            <p>{row.xai?.structured_evidence?.summary || row.why || "Not available"}</p>
            <p className="mt-1 text-xs text-slate-500">XAI method: {row.xai?.method || "Not available"}</p>
            <div className="mt-2 space-y-1">
              {highlights.map((h, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="w-32 truncate text-xs">{h.term}</span>
                  <div className="h-2 flex-1 rounded bg-white/10">
                    <div className={`h-2 rounded ${h.direction === "harmful" ? "bg-rose-400" : "bg-emerald-400"}`} style={{ width: `${Math.min(100, Math.abs(h.contribution) * 400)}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <p className="font-medium text-violet-300">GenAI explanation</p>
            <p>{row.genai_explanation || "GenAI explanation unavailable. Model and XAI results remain available."}</p>
          </div>
          <p className="text-slate-400">Moderation: {row.moderation_recommendation || (row.classification === "UNCERTAIN" ? "Human Review Recommended" : "Human review recommended for high-risk cases. No automatic punishment.")}</p>
        </section>
        <div className="mt-5 flex flex-wrap gap-2">
          <button className="btn" onClick={() => api.review(row.id, "correct")}>Mark correct</button>
          <button className="btn-ghost" onClick={() => api.review(row.id, "incorrect")}>Mark incorrect</button>
          <button className="btn-ghost" onClick={() => api.review(row.id, "needs_review")}>Needs review</button>
        </div>
      </div>
    </div>
  );
}
