import { useEffect, useState } from "react";
import { api } from "../services/api";

export default function SettingsPage() {
  const [data, setData] = useState<any>(null);
  const [high, setHigh] = useState(0.75);
  const [low, setLow] = useState(0.55);
  useEffect(() => {
    api.settings().then((d) => {
      setData(d);
      setHigh(d.high_confidence_threshold);
      setLow(d.low_confidence_threshold);
    });
  }, []);
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold">Settings</h2>
      <div className="card space-y-4 p-5">
        <p>YouTube API: {data?.youtube_configured ? "configured" : "missing — DEMO MODE for comments"}</p>
        <p>GenAI: {data?.genai_configured ? "configured" : "unavailable (fallback active)"}</p>
        <p>Model: {data?.model?.ready ? data.model.selected_model : data?.model?.message || "Requires training"}</p>
        <label className="block text-sm">High confidence threshold {high}
          <input className="w-full" type="range" min={0.5} max={0.99} step={0.01} value={high} onChange={(e) => setHigh(Number(e.target.value))} />
        </label>
        <label className="block text-sm">Low confidence / uncertain threshold {low}
          <input className="w-full" type="range" min={0.2} max={0.8} step={0.01} value={low} onChange={(e) => setLow(Number(e.target.value))} />
        </label>
        <button className="btn" onClick={() => api.saveSettings({ high_confidence_threshold: high, low_confidence_threshold: low }).then(setData)}>Save thresholds</button>
        <p className="text-sm text-slate-400">Keys are read from <code>.env</code> and are never shown. Below the low threshold, classification is UNCERTAIN and human review is recommended.</p>
        <p className="text-sm text-slate-500">AI predictions may contain errors. High-risk content should be reviewed by a human moderator. The system does not ban users.</p>
      </div>
    </div>
  );
}
