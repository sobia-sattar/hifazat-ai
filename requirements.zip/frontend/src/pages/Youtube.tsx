import { useState } from "react";
import CommentDetail from "../components/CommentDetail";
import CommentTable from "../components/CommentTable";
import { DistChart, Metric, PieDist, TrendChart } from "../components/Charts";
import { api } from "../services/api";
import type { AnalysisPayload, CommentRow } from "../types";

export default function YoutubePage() {
  const [url, setUrl] = useState("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  const [data, setData] = useState<AnalysisPayload | null>(null);
  const [open, setOpen] = useState<CommentRow | null>(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function run() {
    setLoading(true);
    setErr("");
    try {
      setData(await api.analyzeYoutube(url));
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  }

  const stats = data?.stats || {};
  const video = data?.video || {};

  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs uppercase tracking-[0.25em] text-sky-400">YouTube</p>
        <h2 className="text-3xl font-semibold">YouTube Analyzer</h2>
      </header>
      <div className="card flex flex-col gap-3 p-5 md:flex-row">
        <input className="input flex-1" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="Paste YouTube URL" />
        <button className="btn" disabled={loading} onClick={run}>{loading ? "Analyzing…" : "Analyze Comments"}</button>
      </div>
      {err && <p className="text-rose-300">{err}</p>}
      {data?.demo_mode && <p className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-200">DEMO MODE — {data.demo_notice}</p>}
      {data?.ok && (
        <>
          <div className="card flex flex-col gap-4 p-5 md:flex-row">
            {video.thumbnail_url ? <img src={video.thumbnail_url} alt="" className="h-28 w-48 rounded-xl object-cover" /> : <div className="grid h-28 w-48 place-items-center rounded-xl bg-white/5 text-xs text-slate-500">No thumbnail</div>}
            <div>
              <h3 className="text-xl font-semibold">{video.title}</h3>
              <p className="text-slate-400">{video.channel}</p>
              <p className="text-sm text-slate-500">{video.published_at || "Published date not available"}</p>
              <p className="text-sm">Comments analyzed: {stats.total}</p>
            </div>
          </div>
          {stats.bullying_rate != null && (
            <div className="card p-6">
              <p className="text-sm text-slate-400">BULLYING DETECTED IN {stats.bullying_rate}% OF ANALYZED COMMENTS</p>
              <p className="text-4xl font-semibold">BULLYING LEVEL {stats.bullying_rate}%</p>
            </div>
          )}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Metric label="Total comments" value={stats.total} />
            <Metric label="Safe" value={stats.safe} accent="text-emerald-300" />
            <Metric label="Bullying" value={stats.bullying} accent="text-rose-300" />
            <Metric label="Harassment" value={stats.harassment} />
            <Metric label="Threats" value={stats.threats} />
            <Metric label="High risk" value={stats.high_risk} />
            <Metric label="Uncertain" value={stats.uncertain} />
            <Metric label="Hate" value={stats.hate} />
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            <PieDist title="Safe vs bullying" data={{ Safe: stats.safe || 0, Bullying: stats.bullying || 0 }} />
            <DistChart title="Bullying percentage context" data={{ Bullying: stats.bullying || 0, Other: (stats.total || 0) - (stats.bullying || 0) }} />
            <DistChart title="Harmful category distribution" data={stats.category_distribution} />
            <DistChart title="Language distribution" data={stats.language_distribution} />
            <DistChart title="Risk distribution" data={stats.risk_distribution} />
            <DistChart title="Confidence distribution" data={stats.confidence_distribution} />
            <PieDist title="English vs Urdu vs Roman Urdu vs Mixed" data={stats.language_distribution} />
            <TrendChart title="Comment toxicity trend" data={stats.trend} />
          </div>
          {data.analysis_id && (
            <div className="flex gap-2">
              <a className="btn-ghost" href={api.exportUrl(data.analysis_id, "csv")}>Export CSV</a>
              <a className="btn-ghost" href={api.exportUrl(data.analysis_id, "json")}>Export JSON</a>
              <a className="btn-ghost" href={api.exportUrl(data.analysis_id, "pdf")}>Export PDF</a>
            </div>
          )}
          <CommentTable rows={data.comments || []} onOpen={setOpen} />
        </>
      )}
      {open && <CommentDetail row={open} onClose={() => setOpen(null)} />}
    </div>
  );
}
