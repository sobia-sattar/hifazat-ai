import { useEffect, useState } from "react";
import { DistChart, Metric, PieDist } from "../components/Charts";
import { api } from "../services/api";
import type { AnalysisPayload } from "../types";

export default function DashboardPage() {
  const [data, setData] = useState<AnalysisPayload | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    api.dashboard().then(setData).catch((e) => setErr(e.message));
  }, []);
  const stats = data?.stats || {};
  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs uppercase tracking-[0.25em] text-sky-400">Operations</p>
        <h2 className="text-3xl font-semibold">Dashboard</h2>
        {data?.demo_mode && <p className="mt-2 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-200">DEMO MODE — {data.demo_notice}</p>}
      </header>
      {err && <p className="text-rose-300">{err}</p>}
      {stats.bullying_rate != null && (
        <div className="card border-rose-500/20 p-6">
          <p className="text-sm text-slate-400">BULLYING DETECTED IN ANALYZED COMMENTS</p>
          <p className="mt-1 text-5xl font-semibold text-rose-300">{stats.bullying_rate}%</p>
          <p className="mt-2 text-sm text-slate-400">BULLYING LEVEL calculated as bullying comments / analyzed comments × 100. Not a claim of 100% accuracy.</p>
        </div>
      )}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Metric label="Total comments" value={stats.total} />
        <Metric label="Safe" value={stats.safe} accent="text-emerald-300" />
        <Metric label="Bullying" value={stats.bullying} accent="text-rose-300" />
        <Metric label="Harassment" value={stats.harassment} />
        <Metric label="Threat" value={stats.threats} />
        <Metric label="High risk" value={stats.high_risk} accent="text-orange-300" />
        <Metric label="Uncertain" value={stats.uncertain} accent="text-amber-300" />
        <Metric label="Bullying %" value={stats.bullying_rate != null ? `${stats.bullying_rate}%` : "Not available"} />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <PieDist title="Safe vs bullying" data={{ Safe: stats.safe || 0, Bullying: stats.bullying || 0, Uncertain: stats.uncertain || 0 }} />
        <DistChart title="Language distribution" data={stats.language_distribution} />
        <DistChart title="Classification / categories" data={stats.category_distribution} />
      </div>
      <section className="card p-4">
        <h3 className="mb-3 text-sm font-medium text-slate-300">Recent high-risk comments</h3>
        <div className="space-y-2">
          {(data?.recent_high_risk || []).length === 0 && <p className="text-sm text-slate-500">No high-risk comments yet.</p>}
          {(data?.recent_high_risk || []).map((c) => (
            <div key={c.id} className="rounded-xl border border-line px-3 py-2 text-sm">
              <p className="text-rose-300">{c.classification} · {(c.confidence * 100).toFixed(1)}% · {c.language}</p>
              <p className="truncate text-slate-200">{c.original_text}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
