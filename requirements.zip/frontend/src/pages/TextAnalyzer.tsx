import { useState } from "react";
import { api } from "../services/api";

export default function TextAnalyzerPage() {
  const [text, setText] = useState("Tum bohat stupid ho");
  const [safer, setSafer] = useState(false);
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function run() {
    setLoading(true);
    setErr("");
    try {
      setData(await api.analyzeText(text, true, safer));
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs uppercase tracking-[0.25em] text-sky-400">Multilingual NLP</p>
        <h2 className="text-3xl font-semibold">Text Analyzer</h2>
      </header>
      <div className="card p-5 space-y-3">
        <textarea className="input min-h-32" value={text} onChange={(e) => setText(e.target.value)} />
        <label className="flex items-center gap-2 text-sm text-slate-300">
          <input type="checkbox" checked={safer} onChange={(e) => setSafer(e.target.checked)} />
          Request safer rephrasing (GenAI, optional)
        </label>
        <button className="btn" disabled={loading || !text.trim()} onClick={run}>{loading ? "Analyzing…" : "Analyze"}</button>
        {err && <p className="text-rose-300">{err}</p>}
      </div>
      {data && <Result data={data} />}
    </div>
  );
}

function Result({ data }: { data: any }) {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="card p-5 space-y-2">
        <p className="text-4xl font-semibold">{data.classification === "BULLYING" ? "🔴 BULLYING" : data.classification}</p>
        <p>Confidence {(data.confidence * 100).toFixed(1)}%</p>
        <p>Language {data.language} ({(data.language_confidence * 100).toFixed(1)}%)</p>
        <p>Script {data.script} · Code-mixed {String(data.is_code_mixed)}</p>
        <p>Risk {data.risk}</p>
        <p className="text-sm text-slate-400">{data.moderation_recommendation}</p>
        <p className="text-xs text-slate-500">{data.ethics}</p>
      </div>
      <div className="card p-5 space-y-2 text-sm">
        <p><span className="text-slate-400">Original</span><br />{data.original_text}</p>
        <p><span className="text-slate-400">Normalized</span><br />{data.normalized_text}</p>
        <div className="flex flex-wrap gap-1">
          {(data.code_mix_tokens || []).map((t: any, i: number) => (
            <span key={i} className="rounded bg-white/5 px-2 py-1 text-xs">{t.token} → {t.language}</span>
          ))}
        </div>
        <p className="text-sky-300">XAI: {data.xai?.structured_evidence?.summary || "Not available"}</p>
        <p className="text-violet-300">GenAI: {data.genai_explanation}</p>
      </div>
    </div>
  );
}
