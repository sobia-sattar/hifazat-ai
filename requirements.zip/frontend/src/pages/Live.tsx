import { useEffect, useState } from "react";
import { DistChart, Metric, TrendChart } from "../components/Charts";
import { api } from "../services/api";

export default function LivePage() {
  const [url, setUrl] = useState("");
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState("");

  async function start() {
    setErr("");
    try {
      setData(await api.liveStart(url));
    } catch (e: any) {
      setErr(e.message);
    }
  }

  useEffect(() => {
    if (data?.status !== "live") return;
    const t = setInterval(() => {
      api.liveStatus().then(setData).catch(() => undefined);
    }, 4000);
    return () => clearInterval(t);
  }, [data?.status]);

  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs uppercase tracking-[0.25em] text-sky-400">Realtime</p>
        <h2 className="text-3xl font-semibold">Live Sentinel</h2>
      </header>
      <div className="card flex flex-col gap-3 p-5 md:flex-row">
        <input className="input flex-1" placeholder="Active livestream URL" value={url} onChange={(e) => setUrl(e.target.value)} />
        <button className="btn" onClick={start}>Start</button>
        <button className="btn-ghost" onClick={() => api.livePause().then(setData)}>Pause</button>
        <button className="btn-ghost" onClick={() => api.liveResume().then(setData)}>Resume</button>
        <button className="btn-ghost" onClick={() => api.liveStop().then(setData)}>Stop</button>
      </div>
      {err && <p className="text-rose-300">{err}</p>}
      {data?.error && <p className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm">{data.error}</p>}
      <p className="text-sm text-slate-400">Status: {data?.status || "offline"} {data?.status === "live" ? "· LIVE" : "· OFFLINE"}</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Metric label="Messages / min" value={data?.messages_per_minute} />
        <Metric label="Total messages" value={data?.total_messages} />
        <Metric label="Safe" value={data?.safe} />
        <Metric label="Bullying" value={data?.bullying} />
        <Metric label="Harassment" value={data?.harassment} />
        <Metric label="Threats" value={data?.threats} />
        <Metric label="High-risk" value={data?.high_risk} />
        <Metric label="Uncertain" value={data?.uncertain} />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Metric label="Bullying rate" value={data?.bullying_rate != null ? `${data.bullying_rate}%` : "Not available"} />
        <DistChart title="Language distribution" data={data?.language_distribution} />
        <DistChart title="Confidence distribution" data={data?.confidence_distribution} />
        <TrendChart title="Time vs bullying" data={data?.trend} />
      </div>
      <div className="card p-4">
        <h3 className="mb-3 text-sm font-medium">Smart alerts</h3>
        {(data?.alerts || []).length === 0 && <p className="text-sm text-slate-500">No alerts. Alerts never automatically punish a user.</p>}
        {(data?.alerts || []).map((a: any, i: number) => (
          <div key={i} className="mb-2 rounded-xl border border-rose-500/30 p-3 text-sm">
            <p className="text-rose-300">{a.alert} · {a.classification} · {(a.confidence * 100).toFixed(1)}% · {a.language}</p>
            <p>{a.message}</p>
            <p className="text-slate-400">{a.xai?.summary}</p>
          </div>
        ))}
      </div>
      <div className="card overflow-hidden">
        <h3 className="border-b border-line px-4 py-3 text-sm">Live message feed</h3>
        {(data?.messages || []).length === 0 && <p className="p-4 text-sm text-slate-500">No live messages. Ordinary comment threads are never shown as live chat.</p>}
        <div className="max-h-96 overflow-y-auto">
          {(data?.messages || []).slice().reverse().map((m: any) => (
            <div key={m.id} className="border-t border-line px-4 py-3 text-sm">
              <p className="text-xs text-slate-500">{m.timestamp} · {m.language} · {m.classification} · {(m.confidence * 100).toFixed(1)}% · {m.risk}</p>
              <p>{m.original_text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
