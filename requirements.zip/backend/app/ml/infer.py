"""Load trained models once and run batch multilingual multi-label inference."""

from __future__ import annotations

import json
from pathlib import Path
from threading import Lock
from typing import Any

import numpy as np

from app.core.config import get_settings
from app.core.runtime import high_threshold, low_threshold
from app.ml.labels import DISPLAY_CATEGORIES, HARMFUL_LABELS, LABELS
from app.nlp.language import detect_language, preprocess_text
from app.nlp.roman_urdu import normalize_roman_urdu
from app.xai.explain import explain_prediction

_lock = Lock()
_bundle: dict[str, Any] | None = None


def models_paths() -> dict[str, Path]:
    d = get_settings().models_dir
    return {
        "dir": d,
        "sklearn": d / "best_sklearn.joblib",
        "meta": d / "model_meta.json",
        "metrics": d / "metrics.json",
        "research": get_settings().research_dir / "results" / "latest.json",
    }


def load_research_metrics() -> dict[str, Any] | None:
    paths = models_paths()
    for p in (paths["research"], paths["metrics"]):
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
    return None


def model_status() -> dict[str, Any]:
    meta_path = models_paths()["meta"]
    metrics = load_research_metrics()
    if not meta_path.exists():
        return {
            "ready": False,
            "message": "Requires training",
            "selected_model": None,
            "metrics_available": metrics is not None,
        }
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    return {
        "ready": True,
        "message": "ready",
        "selected_model": meta.get("selected_model"),
        "selection_criterion": meta.get("selection_criterion"),
        "trained_at": meta.get("trained_at"),
        "metrics_available": metrics is not None,
        "meta": meta,
    }


def get_bundle() -> dict[str, Any] | None:
    global _bundle
    with _lock:
        if _bundle is not None:
            return _bundle
        paths = models_paths()
        if not paths["sklearn"].exists() or not paths["meta"].exists():
            return None
        import joblib

        obj = joblib.load(paths["sklearn"])
        meta = json.loads(paths["meta"].read_text(encoding="utf-8"))
        _bundle = {"sklearn": obj, "meta": meta}
        return _bundle


def _thresholds() -> tuple[float, float]:
    return high_threshold(), low_threshold()


def _risk(classification: str, confidence: float, categories: dict[str, float]) -> str:
    if classification == "UNCERTAIN":
        return "REVIEW"
    threat = float(categories.get("THREAT", 0.0))
    if threat >= 0.75:
        return "CRITICAL"
    if classification != "SAFE" and confidence >= 0.75:
        return "HIGH"
    if classification != "SAFE":
        return "MEDIUM"
    return "LOW"


def _predict_sklearn(text: str, clf_bundle: dict[str, Any]) -> tuple[dict[str, float], Any]:
    pipe = clf_bundle["pipeline"]
    mlb = clf_bundle["labels"]
    if hasattr(pipe, "predict_proba"):
        proba = pipe.predict_proba([text])
        scores = {}
        if isinstance(proba, list):
            for i, name in enumerate(mlb):
                scores[name] = float(np.asarray(proba[i])[0, 1] if np.asarray(proba[i]).ndim == 2 else proba[i][0])
        else:
            arr = np.asarray(proba)[0]
            for i, name in enumerate(mlb):
                scores[name] = float(arr[i]) if i < len(arr) else 0.0
        return scores, pipe
    pred = pipe.predict([text])[0]
    scores = {name: float(pred[i]) for i, name in enumerate(mlb)}
    return scores, pipe


def analyze_text(text: str, include_xai: bool = True) -> dict[str, Any]:
    original = text
    cleaned = preprocess_text(text)
    lang = detect_language(cleaned)
    normalized = normalize_roman_urdu(cleaned) if lang.script in {"latin", "mixed"} else cleaned
    status = model_status()
    bundle = get_bundle()
    high_t, low_t = _thresholds()

    token_map = [{"token": t.token, "language": t.language} for t in lang.tokens]

    if bundle is None:
        return {
            "original_text": original,
            "normalized_text": normalized,
            "language": lang.language,
            "language_confidence": lang.language_confidence,
            "script": lang.script,
            "is_code_mixed": lang.is_code_mixed,
            "code_mix_tokens": token_map,
            "language_evidence": lang.evidence,
            "classification": "UNCERTAIN",
            "display_status": "UNCERTAIN",
            "confidence": 0.0,
            "risk": "REVIEW",
            "categories": {k: 0.0 for k in LABELS},
            "active_categories": [],
            "recommendation": "Human Review Recommended",
            "why": "Requires training",
            "xai": {
                "method": "unavailable",
                "structured_evidence": {"summary": "Requires training"},
                "important_features": [],
                "highlights": [],
            },
            "model": status,
            "moderation_recommendation": "Human Review Recommended — classifier weights are not loaded.",
        }

    clf = bundle["sklearn"]
    scores, pipe = _predict_sklearn(normalized, clf)
    # Ensure all labels present
    for k in LABELS:
        scores.setdefault(k, 0.0)

    harmful_score = max((scores.get(k, 0.0) for k in HARMFUL_LABELS), default=0.0)
    safe_score = scores.get("SAFE", 1.0 - harmful_score)
    primary_harm = max(HARMFUL_LABELS, key=lambda k: scores.get(k, 0.0))
    is_harmful = harmful_score >= 0.5 and harmful_score >= safe_score
    confidence = harmful_score if is_harmful else safe_score

    if confidence < low_t or abs(harmful_score - safe_score) < 0.08:
        classification = "UNCERTAIN"
        display = "UNCERTAIN"
        recommendation = "Human Review Recommended"
    elif is_harmful:
        classification = "BULLYING"
        display = "BULLYING"
        recommendation = "Review harmful content before any moderation action."
    else:
        classification = "SAFE"
        display = "SAFE"
        recommendation = "No automatic action. Predictions may still contain errors."

    active = [
        {"id": k, "label": DISPLAY_CATEGORIES[k], "score": round(scores[k], 4)}
        for k in HARMFUL_LABELS
        if scores.get(k, 0.0) >= 0.5
    ]
    risk = _risk(classification, confidence, scores)
    label_index = LABELS.index(primary_harm if is_harmful else "SAFE")

    def proba_fn(t: str) -> list[float]:
        s, _ = _predict_sklearn(t, clf)
        return [s.get(k, 0.0) for k in LABELS]

    xai = {"method": "unavailable", "important_features": [], "highlights": [], "structured_evidence": {}}
    if include_xai:
        xai = explain_prediction(
            text=cleaned,
            normalized=normalized,
            probabilities=scores,
            primary_label=primary_harm if is_harmful else "SAFE",
            pipeline=pipe,
            predict_proba_fn=proba_fn,
            class_index=label_index,
        )

    why = (xai.get("structured_evidence") or {}).get("summary") or ""
    return {
        "original_text": original,
        "normalized_text": normalized,
        "language": lang.language,
        "language_confidence": lang.language_confidence,
        "script": lang.script,
        "is_code_mixed": lang.is_code_mixed,
        "code_mix_tokens": token_map,
        "language_evidence": lang.evidence,
        "classification": classification,
        "display_status": display,
        "confidence": round(float(confidence), 4),
        "risk": risk,
        "categories": {k: round(float(v), 4) for k, v in scores.items()},
        "active_categories": active,
        "primary_category": primary_harm if is_harmful else "SAFE",
        "recommendation": recommendation,
        "why": why,
        "xai": xai,
        "model": {
            "name": bundle["meta"].get("selected_model"),
            "ready": True,
        },
        "moderation_recommendation": recommendation,
        "thresholds": {"high": high_t, "low": low_t},
    }


def analyze_batch(texts: list[str], include_xai: bool = True) -> list[dict[str, Any]]:
    get_bundle()  # load once
    return [analyze_text(t, include_xai=include_xai) for t in texts]
